Replace these placeholder images with your own photos. Keep the same file names.

braids-skin-fade-line-design-400.jpg ... classic-taper-haircut-400.jpg   400 x 400 px  (thumbnails)
braids-skin-fade-line-design-800.jpg ... classic-taper-haircut-800.jpg   800 x 800 px  (shown in the viewer)
barbershop-featured-cut-600.jpg                          600 x 400 px  (home page, mobile and tablet)
barbershop-featured-cut-1200.jpg                         1200 x 800 px (home page, desktop)

After swapping a photo, update its alt text (and caption) in the HTML so it describes the real image.
